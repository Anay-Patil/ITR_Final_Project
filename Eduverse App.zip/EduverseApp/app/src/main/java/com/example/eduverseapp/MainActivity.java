package com.example.eduverseapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private static int SPLASH_SCREEN=7000;
    ImageView i;
    TextView t1,t2,t3,t4,t5;
    Animation updowntext,alphatext,translatetext,translatetext1,translateimage;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setContentView(R.layout.activity_main);
        i = findViewById(R.id.img);
        t1=findViewById(R.id.alpha);
        t2=findViewById(R.id.trans);
        t3=findViewById(R.id.trans1);
        t4=findViewById(R.id.t1);
        t5=findViewById(R.id.t2);

        updowntext= AnimationUtils.loadAnimation(this,R.anim.updown);
        t4.startAnimation(updowntext);
        t5.startAnimation(updowntext);

        alphatext=AnimationUtils.loadAnimation(this,R.anim.translate);
        t1.startAnimation(alphatext);

        translatetext=AnimationUtils.loadAnimation(this,R.anim.alpha);
        t2.startAnimation(translatetext);

        translatetext1=AnimationUtils.loadAnimation(this,R.anim.translate1);
        t3.startAnimation(translatetext1);

        translateimage=AnimationUtils.loadAnimation(this,R.anim.image);
        i.startAnimation(translateimage);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent i = new Intent(MainActivity.this,welcome.class);
                startActivity(i);
            }
        },SPLASH_SCREEN);
    }
}