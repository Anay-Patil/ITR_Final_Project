package com.example.eduverseapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class login extends AppCompatActivity {
    // Creating instances/variables
    EditText loginemail,loginpassword;
    TextView t1;
    TextView signup;
    Button b1;
    FirebaseAuth f1;
    Animation logintext;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        signup = findViewById(R.id.sp);
        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(login.this,signup.class);
                startActivity(i);
            }
        });
        // Linking or casting objects to xml controls
        f1=FirebaseAuth.getInstance();
        t1 = findViewById(R.id.login1);
        loginemail=findViewById(R.id.email);
        loginpassword=findViewById(R.id.pass);
        b1 = findViewById(R.id.login);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String user_email = loginemail.getText().toString();
                String user_pass = loginpassword.getText().toString();
                f1.signInWithEmailAndPassword(user_email,user_pass).addOnSuccessListener(login.this, new OnSuccessListener<AuthResult>() {
                    @Override
                    public void onSuccess(AuthResult authResult) {
                        Toast.makeText(login.this,"LOGIN SUCCESSFULLY!!",Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(login.this, homescreen.class));
                    }
                });


            }
        });
        logintext = AnimationUtils.loadAnimation(this,R.anim.login);
        t1.startAnimation(logintext);



    }
}